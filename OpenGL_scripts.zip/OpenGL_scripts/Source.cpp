#include"imgui/imgui.h"
#include "imgui/imgui_impl_glfw.h"
#include "imgui/imgui_impl_opengl3.h"

#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "glm/gtc/type_ptr.hpp"

#include "shader_s.h"
//#define STB_IMAGE_IMPLEMENTATION
//#include "stb_image.h"
#include "texture.h"


#include <iostream>
#include <bitset>


void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods);

void processInput(GLFWwindow* window);

//constants
constexpr float PI = 3.14159274101257324219f;

// settings
const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 800;
bool isImGUIMode = false;

// camera
float lastX = (float)SCR_WIDTH / 2.0;
float lastY = (float)SCR_HEIGHT / 2.0;
bool firstMouse = true;

// timing
float deltaTime = 0.0f;	// time between current frame and last frame
float lastFrame = 0.0f;


//input
std::uint_fast8_t inputs{};
constexpr std::uint_fast8_t key_a{ 1 << 0 }; // 0000 0001
constexpr std::uint_fast8_t key_s{ 1 << 1 }; // 0000 0010
constexpr std::uint_fast8_t key_d{ 1 << 2 }; // 0000 0100
constexpr std::uint_fast8_t key_w{ 1 << 3 }; // 0000 1000
constexpr std::uint_fast8_t key_lshift{ 1 << 4 }; // 0001 0000

#include "camera.h"
Camera camera(glm::vec3(0.0f, 0.0f, 3.0f));


int main()
{
    // glfw: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // glfw window creation
    // --------------------
    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "LearnOpenGL", NULL, NULL);
    if (window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetCursorPosCallback(window, mouse_callback);
    glfwSetScrollCallback(window, scroll_callback);
    glfwSetKeyCallback(window, key_callback);

    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    //glfwSetCursorPosCallback(window, cursor_position_callback);
    // GLEW: load all OpenGL function pointers
    // ---------------------------------------
    if (GLEW_OK != glewInit())
    {
        std::cout << "Failed to initialize GLEW!" << std::endl;
        return -1;
    }

    glEnable(GL_DEPTH_TEST);


    float vertices[] = {
        // positions          // normals           // texture coords
        -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,
         0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,
         0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,
         0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,
        -0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 1.0f,
        -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,

        -0.5f, -0.5f,  0.5f,  0.0f,  0.0f, 1.0f,   0.0f, 0.0f,
         0.5f, -0.5f,  0.5f,  0.0f,  0.0f, 1.0f,   1.0f, 0.0f,
         0.5f,  0.5f,  0.5f,  0.0f,  0.0f, 1.0f,   1.0f, 1.0f,
         0.5f,  0.5f,  0.5f,  0.0f,  0.0f, 1.0f,   1.0f, 1.0f,
        -0.5f,  0.5f,  0.5f,  0.0f,  0.0f, 1.0f,   0.0f, 1.0f,
        -0.5f, -0.5f,  0.5f,  0.0f,  0.0f, 1.0f,   0.0f, 0.0f,

        -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
        -0.5f,  0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 1.0f,
        -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
        -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
        -0.5f, -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 0.0f,
        -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,

         0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
         0.5f,  0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 1.0f,
         0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
         0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
         0.5f, -0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 0.0f,
         0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f,

        -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 1.0f,
         0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 1.0f,
         0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 0.0f,
         0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 0.0f,
        -0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 0.0f,
        -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 1.0f,

        -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 1.0f,
         0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 1.0f,
         0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 0.0f,
         0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 0.0f,
        -0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 0.0f,
        -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 1.0f
    };

    // positions all containers
    glm::vec3 cubePositions[] = {
        glm::vec3(0.0f,  0.0f,  0.0f),
        glm::vec3(2.0f,  5.0f, -15.0f),
        glm::vec3(-1.5f, -2.2f, -2.5f),
        glm::vec3(-3.8f, -2.0f, -12.3f),
        glm::vec3(2.4f, -0.4f, -3.5f),
        glm::vec3(-1.7f,  3.0f, -7.5f),
        glm::vec3(1.3f, -2.0f, -2.5f),
        glm::vec3(1.5f,  2.0f, -2.5f),
        glm::vec3(1.5f,  0.2f, -1.5f),
        glm::vec3(-1.3f,  1.0f, -1.5f)
    };
    // positions of the point lights
    glm::vec3 pointLightPositions[] = {
        glm::vec3(0.7f,  0.2f,  2.0f),
        glm::vec3(2.3f, -3.3f, -4.0f),
        glm::vec3(-4.0f,  2.0f, -12.0f),
        glm::vec3(0.0f,  0.0f, -3.0f)
    };

    unsigned int VBO, VAO/*, EBO*/;
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    //glGenBuffers(1, &EBO);

    glBindVertexArray(VAO);

    int stride = 8;
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    /*glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);*/

    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    //// normals  attribute
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride * sizeof(float), (void*) (3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    //// texture  attribute
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, stride * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);


    unsigned int lightCubeVAO;
    glGenVertexArrays(1, &lightCubeVAO);
    glBindVertexArray(lightCubeVAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);


    // load and create a texture 
    // -------------------------
    const char* texture0Path = R"(.\res\images\containter_diffuseMap.png)";
    const char* texture1Path = R"(.\res\images\container_specularMap.png)";
    const char* texture2Path = R"(.\res\images\matrix.jpg)";

    Textures textures;
    unsigned int diffuseMap = textures.AddTexture(texture0Path);
    unsigned int specularMap = textures.AddTexture(texture1Path);
    unsigned int emissionMap = textures.AddTexture(texture2Path);



    // build and compile our shader program
    // ------------------------------------
    const char* light_source_FragPath = "C:/OpenGL/OpenGL/OpenGL/res/shaders/light_source.frag";
    const char* light_source_VertPath = "C:/OpenGL/OpenGL/OpenGL/res/shaders/light_source.vert";
    const char* fragShaderPath = "C:/OpenGL/OpenGL/OpenGL/res/shaders/fragShader.frag";
    const char* vertexShaderPath = "C:/OpenGL/OpenGL/OpenGL/res/shaders/vertexShader.vert";

    Shader light_dest(vertexShaderPath, fragShaderPath);
    Shader light_source(light_source_VertPath, light_source_FragPath);
    


    //imgui begin
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    ImGui::StyleColorsDark();
    ImGui_ImplGlfw_InitForOpenGL(window, true);
    ImGui_ImplOpenGL3_Init("#version 330");


    //-------------------loop globals-----------------//

    float lightRotSpeed = 0.3f;
    float lightTime = 0.0f;
    float lightRadius = 8.0f;

    //material
    struct Material{
        glm::vec3 ambient;
        glm::vec3 diffuse;
        glm::vec3 specular;
        float shininess;
    };
    Material material;
    /*material.ambient = glm::vec3(1.0f, 1.0f, 1.0f);
    material.diffuse = glm::vec3(1.0f, 1.0f, 1.0f);*/
    material.specular = glm::vec3(1.0f, 1.0f, 1.0f);
    material.shininess = 1.0f;

    //light
    struct Light {
        glm::vec3 position;
        glm::vec3 direction;

        glm::vec3 ambient;
        glm::vec3 diffuse;
        glm::vec3 specular;

        float constant;
        float linear;
        float quadratic;

        float innerCutoffAngle;
        float outerCutoffAngle;

    };
    Light light;
    light.position = glm::vec3(1.2f, 1.0f, 2.0f);
    light.direction = glm::vec3(0.0f, -1.0f, 0.0f);

    light.ambient = glm::vec3(0.2f, 0.2f, 0.2f);
    light.diffuse = glm::vec3(1.0f, 1.0f, 1.0f);
    light.specular = glm::vec3(1.0f, 1.0f, 1.0f);

    light.constant = 1.0f;
    light.linear = 0.09f;
    light.quadratic = 0.032f;
    light.innerCutoffAngle = 25.0f;
    light.outerCutoffAngle = 45.0f;



    //---------------------------------------------------//

    light_dest.use();
    light_dest.setInt("material.diffuse", 0);
    light_dest.setInt("material.specular", 1);
    light_dest.setInt("material.emission", 2);


    // render loop
    // -----------
    while (!glfwWindowShouldClose(window))
    {
        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();

        // per-frame time logic
        // --------------------
        float currentFrame = glfwGetTime();
        deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;

        // input
        // -----
        processInput(window);

        // render
        // ------
        glClearColor(0.5f, 0.5f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        //ImGui
        {
        ImGui::Begin("##default");
        ImGui::Text("Material settings");
        ImGui::SliderFloat("shininess", &material.shininess, 0.0f, 256.0f);
        /*ImGui::ColorEdit3("ambient", glm::value_ptr(material.ambient));
        ImGui::ColorEdit3("diffuse", glm::value_ptr(material.diffuse));*/
        //ImGui::ColorEdit3("specular", glm::value_ptr(material.specular));
        ImGui::Text("Light settings");
       /* ImGui::SliderFloat("position", &lightTime, 0.0f, 8.f*PI);
        ImGui::SliderFloat("radius", &lightRadius, 0.0f, 10.0f);*/
        ImGui::SliderFloat3("position##light", glm::value_ptr(light.position), -10.0f, 10.0f);
        ImGui::SliderFloat3("direction##light", glm::value_ptr(light.direction), -1.0f,1.0f);
        ImGui::ColorEdit3("ambient##light", glm::value_ptr(light.ambient));
        ImGui::ColorEdit3("diffuse##light", glm::value_ptr(light.diffuse));
        ImGui::ColorEdit3("specular##light", glm::value_ptr(light.specular));
        ImGui::SliderFloat("inner cutoff##light", &light.innerCutoffAngle, 0.0f,90.f);
        ImGui::SliderFloat("outer cutoff##light", &light.outerCutoffAngle, light.innerCutoffAngle, 90.f);


        ImGui::End();
        }


        //lightTime = (float)glfwGetTime() * lightRotSpeed;
        //lightTime *= lightRotSpeed;

        //light.position = glm::vec3(cos(lightTime) * lightRadius, sin(lightTime /2.0f) * 3.0f , sin(lightTime) * lightRadius);


        light_dest.use();
        // directional light
        light_dest.setVec3("dirLight.direction", -0.2f, -1.0f, -0.3f);
        light_dest.setVec3("dirLight.ambient", 0.05f, 0.05f, 0.05f);
        light_dest.setVec3("dirLight.diffuse", 0.4f, 0.4f, 0.4f);
        light_dest.setVec3("dirLight.specular", 0.5f, 0.5f, 0.5f);
        // point light 1
        light_dest.setVec3("pointLights[0].position", pointLightPositions[0]);
        light_dest.setVec3("pointLights[0].ambient", 0.05f, 0.05f, 0.05f);
        light_dest.setVec3("pointLights[0].diffuse", 0.8f, 0.8f, 0.8f);
        light_dest.setVec3("pointLights[0].specular", 1.0f, 1.0f, 1.0f);
        light_dest.setFloat("pointLights[0].constant", 1.0f);
        light_dest.setFloat("pointLights[0].linear", 0.09);
        light_dest.setFloat("pointLights[0].quadratic", 0.032);
        // point light 2
        light_dest.setVec3("pointLights[1].position", pointLightPositions[1]);
        light_dest.setVec3("pointLights[1].ambient", 0.05f, 0.05f, 0.05f);
        light_dest.setVec3("pointLights[1].diffuse", 0.8f, 0.8f, 0.8f);
        light_dest.setVec3("pointLights[1].specular", 1.0f, 1.0f, 1.0f);
        light_dest.setFloat("pointLights[1].constant", 1.0f);
        light_dest.setFloat("pointLights[1].linear", 0.09);
        light_dest.setFloat("pointLights[1].quadratic", 0.032);
        // point light 3
        light_dest.setVec3("pointLights[2].position", pointLightPositions[2]);
        light_dest.setVec3("pointLights[2].ambient", 0.05f, 0.05f, 0.05f);
        light_dest.setVec3("pointLights[2].diffuse", 0.8f, 0.8f, 0.8f);
        light_dest.setVec3("pointLights[2].specular", 1.0f, 1.0f, 1.0f);
        light_dest.setFloat("pointLights[2].constant", 1.0f);
        light_dest.setFloat("pointLights[2].linear", 0.09);
        light_dest.setFloat("pointLights[2].quadratic", 0.032);
        // point light 4
        light_dest.setVec3("pointLights[3].position", pointLightPositions[3]);
        light_dest.setVec3("pointLights[3].ambient", 0.05f, 0.05f, 0.05f);
        light_dest.setVec3("pointLights[3].diffuse", 0.8f, 0.8f, 0.8f);
        light_dest.setVec3("pointLights[3].specular", 1.0f, 1.0f, 1.0f);
        light_dest.setFloat("pointLights[3].constant", 1.0f);
        light_dest.setFloat("pointLights[3].linear", 0.09);
        light_dest.setFloat("pointLights[3].quadratic", 0.032);
        // spotLight
        light_dest.setVec3("spotLight.position", camera.Position);
        light_dest.setVec3("spotLight.direction", camera.Front);
        light_dest.setVec3("spotLight.ambient", 0.0f, 0.0f, 0.0f);
        light_dest.setVec3("spotLight.diffuse", 1.0f, 1.0f, 1.0f);
        light_dest.setVec3("spotLight.specular", 1.0f, 1.0f, 1.0f);
        light_dest.setFloat("spotLight.constant", 1.0f);
        light_dest.setFloat("spotLight.linear", 0.09);
        light_dest.setFloat("spotLight.quadratic", 0.032);
        light_dest.setFloat("spotLight.cutOff", glm::cos(glm::radians(12.5f)));
        light_dest.setFloat("spotLight.outerCutOff", glm::cos(glm::radians(15.0f)));

        ///*light_dest.setVec3("material.ambient", material.ambient);
        //light_dest.setVec3("material.diffuse", material.diffuse);*/
        //light_dest.setVec3("material.specular", material.specular);
        //light_dest.setFloat("material.shininess", material.shininess);
        //light_dest.setVec3("light.ambient", light.ambient);
        //light_dest.setVec3("light.diffuse", light.diffuse);
        //light_dest.setVec3("light.specular", light.specular);
        //light_dest.setVec3("light.position", light.position);
        //light_dest.setVec3("light.direction", light.direction);
        //light_dest.setVec3("viewPos", camera.Position);
        //light_dest.setFloat("light.constant", light.constant);
        //light_dest.setFloat("light.linear", light.linear);
        //light_dest.setFloat("light.quadratic", light.quadratic);
        //light_dest.setFloat("light.innerCutoff", glm::cos(glm::radians(light.innerCutoffAngle)));
        //light_dest.setFloat("light.outerCutoff", glm::cos(glm::radians(light.outerCutoffAngle)));

        textures.BindTexture(diffuseMap);
        textures.BindTexture(specularMap);
        textures.BindTexture(emissionMap);



        // view/projection transformations
        glm::mat4 projection = glm::perspective(glm::radians(camera.Zoom), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);
        glm::mat4 view = camera.GetViewMatrix();
        light_dest.setMat4("projection", projection);
        light_dest.setMat4("view", view);

        // world transformation
        //glm::mat4 model = glm::mat4(1.0f);
        /*model = glm::scale(model, glm::vec3(10.0f, 0.1f, 10.0f));
        light_dest.setMat4("model", model);*/
        

        //glDrawArrays(GL_TRIANGLES, 0, 36);

        // render the cubes
        /*int size = 3;
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                for (int k = 0; k < size; k++) {
                    float offset = size / 2.0f;
                    model = glm::mat4(1.0f);
                    model = glm::translate(model, glm::vec3(i - offset, j - offset, k - offset));
                    model = glm::scale(model, glm::vec3(0.5f, 0.5f, 0.5f));
                    model = glm::rotate(model, (float)glfwGetTime() + k, glm::vec3(0.1f, 0.5f, 0.9f));


                    light_dest.setMat4("model", model);
                    glDrawArrays(GL_TRIANGLES, 0, 36);

                }
            }
        }*/
        glm::mat4 model = glm::mat4(1.0f);
        glBindVertexArray(VAO);
        for (unsigned int i = 0; i < 10; i++)
        {
            // calculate the model matrix for each object and pass it to shader before drawing
            model = glm::mat4(1.0f);
            model = glm::translate(model, cubePositions[i]);
            float angle = 20.0f * i;
            model = glm::rotate(model, glm::radians(angle), glm::vec3(1.0f, 0.3f, 0.5f));
            light_dest.setMat4("model", model);
            glDrawArrays(GL_TRIANGLES, 0, 36);
        }

        // also draw the lamp object
        light_source.use();
        light_source.setMat4("projection", projection);
        light_source.setMat4("view", view);
        // we now draw as many light bulbs as we have point lights.
        glBindVertexArray(lightCubeVAO);
        for (unsigned int i = 0; i < 4; i++)
        {
            model = glm::mat4(1.0f);
            model = glm::translate(model, pointLightPositions[i]);
            model = glm::scale(model, glm::vec3(0.2f)); // Make it a smaller cube
            light_source.setMat4("model", model);
            glDrawArrays(GL_TRIANGLES, 0, 36);
        }




        //render ImGui
        ImGui::Render();
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
        // -------------------------------------------------------------------------------
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    // optional: de-allocate all resources once they've outlived their purpose:
    // ------------------------------------------------------------------------
    
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    //glDeleteBuffers(1, &EBO);

    // glfw: terminate, clearing all previously allocated GLFW resources.
    // ------------------------------------------------------------------
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();
    glfwTerminate();
    return 0;
}



// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
void processInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

   /* if (glfwGetKey(window, GLFW_KEY_TAB) == GLFW_PRESS) {
        if (isImGUIMode)
            glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
        else
            glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
        isImGUIMode = !isImGUIMode; 
    }*/

    
    
    if (glfwGetKey(window, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS)
        inputs |= key_lshift;
     if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        inputs |= key_w;
     if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        inputs |= key_s;
     if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        inputs |= key_a;
     if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        inputs |= key_d;

     camera.ProcessKeyboardAndMove(inputs, deltaTime);

     inputs &= 0;
}

void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods) {
    if (key == GLFW_KEY_TAB && action == GLFW_PRESS) {
        if (isImGUIMode) {
            firstMouse = true;
            glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
        }
        else
            glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
        isImGUIMode = !isImGUIMode; 
    }

}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    // make sure the viewport matches the new window dimensions; note that width and 
    // height will be significantly larger than specified on retina displays.
    glViewport(0, 0, width, height);
}

void mouse_callback(GLFWwindow* window, double xpos, double ypos) 
{
    if (isImGUIMode)
        return;

    if (firstMouse) {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }

    float xoffset = xpos - lastX;
    float yoffset = lastY - ypos;
    lastX = xpos;
    lastY = ypos;

    camera.ProcessMouseMovement(xoffset, yoffset);
}

void scroll_callback(GLFWwindow* window, double xoffset, double yoffset) {
    camera.ProcessMouseScroll(yoffset);
}


